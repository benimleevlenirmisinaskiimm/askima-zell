# Proposal with plane ✈️💍

Coded with CSS, HTML and JavaScript

https://github.com/elifgazioglu/will-you-marry-me/assets/103602957/f98c46bf-32ac-4d51-8530-35562746d159

